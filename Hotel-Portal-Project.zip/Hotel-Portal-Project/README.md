# Hotel-Management-System

This portal will enable the users to compare the prices of available rooms in hotels in different locations across India and book the rooms of their choice.

## Tools used
  IDE - Eclipse
  
  
  Database - MySQL 
   
